package controller;

import controller.ConexaoMySql;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Reservas;
import model.Funcionario;

public class DAOFuncionarios {
   
   //método construtor vazio
   public DAOFuncionarios(){
       if(ConexaoMySql.getConnection() == null){
           ConexaoMySql.createConnection();
       }
   } 
   
   public boolean atualizarFuncionario(Funcionario funcionario){
       String sql = "UPDATE funcionario SET func_nome='"+funcionario.getNome()+"', func_cpf='"+funcionario.getCpf()+"', func_rg='"+funcionario.getRg()+"', func_sexo='"+funcionario.getSexo()+"', func_telefone='"+funcionario.getTelefone()+"', func_email='"+funcionario.getEmail()+"', func_ctps='"+funcionario.getCTPS()+"', func_salario="+funcionario.getSalario()+" WHERE func_id="+funcionario.getCodigo()+"";
       return ConexaoMySql.atualizar(sql);
   }
   
   public boolean salvarFuncionario(Funcionario funcionario){
       String sql = "INSERT INTO funcionario (func_nome, func_cpf, func_rg,func_sexo,func_telefone,func_email,func_ctps,func_salario) VALUES ('"+funcionario.getNome()+"', '"+funcionario.getCpf()+"','"+funcionario.getRg()+"', '"+funcionario.getSexo()+"', '"+funcionario.getTelefone()+"', '"+funcionario.getEmail()+"', '"+funcionario.getCTPS()+"', "+funcionario.getSalario()+")";
       System.out.println(sql);
       return ConexaoMySql.atualizar(sql); 
   }
   
   public boolean deletarFuncionario(int id){ 
      String sql = "DELETE FROM funcionario WHERE func_id="+id;
      boolean status = ConexaoMySql.atualizar(sql);
      return status;
   }

    public List<Funcionario> getFuncionario(String colunaOrderBy){   
        //Preenche um resultset com os dados do banco
        ConexaoMySql.selecionar("SELECT * FROM funcionario ORDER BY "+colunaOrderBy);
        
        List<Funcionario> listaFuncionarios = new ArrayList<>();
        
        try {
            while(ConexaoMySql.resultset.next()){  
                Funcionario funcionario = new Funcionario();
                funcionario.setCodigo(ConexaoMySql.resultset.getInt("func_id")); 
                funcionario.setNome(ConexaoMySql.resultset.getString("func_nome"));
                funcionario.setSexo(ConexaoMySql.resultset.getString("func_sexo"));
                funcionario.setCpf(ConexaoMySql.resultset.getString("func_cpf"));
                funcionario.setRg(ConexaoMySql.resultset.getString("func_rg"));
                funcionario.setTelefone(ConexaoMySql.resultset.getString("func_telefone"));
                funcionario.setEmail(ConexaoMySql.resultset.getString("func_email"));
                funcionario.setCTPS(ConexaoMySql.resultset.getString("func_ctps"));
                funcionario.setSalario(ConexaoMySql.resultset.getDouble("func_salario"));
                

                listaFuncionarios.add(funcionario);         
            }           
        } catch (SQLException ex) {
            System.out.println("ERRO!");
        }
        
        
        return listaFuncionarios;
    }
    
    public List<Funcionario> getFiltrarFuncionario(String colunaOrderBy, String colunaFiltro, String valor){   
        //Preenche um resultset com os dados do banco
        ConexaoMySql.selecionar("SELECT * FROM funcionario WHERE "+colunaFiltro+" LIKE '%"+valor+"%' ORDER BY "+colunaOrderBy);
        
        List<Funcionario> listaFuncionarios = new ArrayList<>();
        
        try {
            while(ConexaoMySql.resultset.next()){  
                Funcionario funcionario = new Funcionario();
                funcionario.setCodigo(ConexaoMySql.resultset.getInt("func_id")); 
                funcionario.setNome(ConexaoMySql.resultset.getString("func_nome"));
                funcionario.setSexo(ConexaoMySql.resultset.getString("func_sexo"));
                funcionario.setCpf(ConexaoMySql.resultset.getString("func_cpf"));
                funcionario.setRg(ConexaoMySql.resultset.getString("func_rg"));
                funcionario.setTelefone(ConexaoMySql.resultset.getString("func_telefone"));
                funcionario.setEmail(ConexaoMySql.resultset.getString("func_email"));
                funcionario.setCTPS(ConexaoMySql.resultset.getString("func_ctps"));
                funcionario.setSalario(ConexaoMySql.resultset.getDouble("func_salario"));

                listaFuncionarios.add(funcionario);           
            }           
        } catch (SQLException ex) {
            System.out.println("ERRO!");
        }
        
        return listaFuncionarios;
    }
    
    
        
 
}
