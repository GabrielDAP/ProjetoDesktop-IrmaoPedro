package controller;

import controller.ConexaoMySql;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Reservas;
import model.Cliente;

public class DAOClientes {
   
   //método construtor vazio
   public DAOClientes(){
       if(ConexaoMySql.getConnection() == null){
           ConexaoMySql.createConnection();
       }
   } 
   
   public boolean atualizarCliente(Cliente cliente){
       String sql = "UPDATE cliente SET cliente_nome='"+cliente.getNome()+"', cliente_cpf='"+cliente.getCpf()+"', cliente_rg='"+cliente.getRg()+"', cliente_sexo='"+cliente.getSexo()+"', reservas_id="+cliente.getReservas().getCodigo()+" WHERE cliente_id="+cliente.getCodigo()+"";
       return ConexaoMySql.atualizar(sql);
   }
   
   public boolean salvarCliente(Cliente cliente){
       String sql = "INSERT INTO cliente (cliente_nome, cliente_cpf,cliente_rg,cliente_sexo,reservas_id) VALUES ('"+cliente.getNome()+"', '"+cliente.getCpf()+"','"+cliente.getRg()+"', '"+cliente.getSexo()+"',"+cliente.getReservas().getCodigo()+")";
       System.out.println(sql);
       return ConexaoMySql.atualizar(sql); 
   }
   
   public boolean deletarCliente(int id){ 
      String sql = "DELETE FROM cliente WHERE cliente_id="+id;
      boolean status = ConexaoMySql.atualizar(sql);
      return status;
   }

    public List<Cliente> getCliente(String colunaOrderBy){   
        //Preenche um resultset com os dados do banco
        ConexaoMySql.selecionar("SELECT * FROM cliente, reserva WHERE cliente.reservas_id = reserva.reservas_id ORDER BY "+colunaOrderBy);
        
        List<Cliente> listaClientes = new ArrayList<>();
        
        try {
            while(ConexaoMySql.resultset.next()){  
                Cliente cliente = new Cliente();
                cliente.setCodigo(ConexaoMySql.resultset.getInt("cliente_id")); 
                cliente.setNome(ConexaoMySql.resultset.getString("cliente_nome"));
                cliente.setSexo(ConexaoMySql.resultset.getString("cliente_sexo"));
                cliente.setCpf(ConexaoMySql.resultset.getString("cliente_cpf"));
                cliente.setRg(ConexaoMySql.resultset.getString("cliente_rg"));
                
                Reservas reservas = new Reservas();
                reservas.setCodigo(ConexaoMySql.resultset.getInt("reservas_id")); 
                reservas.setNumero(ConexaoMySql.resultset.getString("reservas_numero"));
                reservas.setStatus(ConexaoMySql.resultset.getString("reservas_status"));
                reservas.setData(ConexaoMySql.resultset.getString("reservas_datadereserva"));
                reservas.setCusto(ConexaoMySql.resultset.getDouble("reservas_custo"));

                cliente.setReservas(reservas);
                
                listaClientes.add(cliente);         
            }           
        } catch (SQLException ex) {
            System.out.println("ERRO!");
        }
        
        
        return listaClientes;
    }
    
    public List<Cliente> getFiltrarCliente(String colunaOrderBy, String colunaFiltro, String valor){   
        //Preenche um resultset com os dados do banco
        ConexaoMySql.selecionar("SELECT * FROM cliente, reserva WHERE cliente.reservas_id = reserva.reservas_id AND "+colunaFiltro+" LIKE '%"+valor+"%' ORDER BY "+colunaOrderBy);
        
        List<Cliente> listaClientes = new ArrayList<>();
        
        try {
            while(ConexaoMySql.resultset.next()){  
                Cliente cliente = new Cliente();
                cliente.setCodigo(ConexaoMySql.resultset.getInt("cliente_id")); 
                cliente.setNome(ConexaoMySql.resultset.getString("cliente_nome"));
                cliente.setSexo(ConexaoMySql.resultset.getString("cliente_sexo"));
                cliente.setCpf(ConexaoMySql.resultset.getString("cliente_cpf"));
                cliente.setRg(ConexaoMySql.resultset.getString("cliente_rg"));
                
                Reservas reservas = new Reservas();
                reservas.setCodigo(ConexaoMySql.resultset.getInt("reservas_id")); 
                reservas.setNumero(ConexaoMySql.resultset.getString("reservas_numero"));
                reservas.setStatus(ConexaoMySql.resultset.getString("reservas_status"));
                reservas.setData(ConexaoMySql.resultset.getString("reservas_datadereserva"));
                reservas.setCusto(ConexaoMySql.resultset.getDouble("reservas_custo"));

                cliente.setReservas(reservas);
                
                listaClientes.add(cliente);              
            }           
        } catch (SQLException ex) {
            System.out.println("ERRO!");
        }
        
        return listaClientes;
    }
    
    
        
 
}
