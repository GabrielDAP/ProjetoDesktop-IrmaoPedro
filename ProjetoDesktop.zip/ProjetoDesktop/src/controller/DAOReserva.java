package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Reservas;

public class DAOReserva {
   
   //método construtor vazio
   public DAOReserva(){
       if(ConexaoMySql.getConnection() == null){
           ConexaoMySql.createConnection();
       }
   } 
   
   public boolean atualizarReservas(Reservas reservas){
       String sql = "UPDATE reserva SET reservas_numero='"+reservas.getNumero()+"', reservas_datadereserva='"+reservas.getData()+"',reservas_custo="+reservas.getCusto()+", reservas_status='"+reservas.getStatus()+"' WHERE reservas_id="+reservas.getCodigo()+"";
       return ConexaoMySql.atualizar(sql);
   }
   
   public boolean salvarReservas(Reservas reservas){
       String sql = "INSERT INTO reserva (reservas_numero, reservas_datadereserva,reservas_custo,reservas_status) VALUES ('"+reservas.getNumero()+"', '"+reservas.getData()+"', "+reservas.getCusto()+", '"+reservas.getStatus()+"')";
       return ConexaoMySql.atualizar(sql); 
   }
   
   public boolean deletarReservas(int id){ 
      String sql = "DELETE FROM reserva WHERE reservas_id="+id;
      boolean status = ConexaoMySql.atualizar(sql);
      return status;
   }

    public List<Reservas> getReservas(String colunaOrderBy){   
        //Preenche um resultset com os dados do banco
        ConexaoMySql.selecionar("SELECT * FROM reserva ORDER BY "+colunaOrderBy);
        
        List<Reservas> listaCargo = new ArrayList<>();
        
        try {
            while(ConexaoMySql.resultset.next()){  
                Reservas reservas = new Reservas();
                reservas.setCodigo(ConexaoMySql.resultset.getInt("reservas_id")); 
                reservas.setNumero(ConexaoMySql.resultset.getString("reservas_numero"));
                reservas.setStatus(ConexaoMySql.resultset.getString("reservas_status"));
                reservas.setData(ConexaoMySql.resultset.getString("reservas_datadereserva"));
                reservas.setCusto(ConexaoMySql.resultset.getDouble("reservas_custo"));

                listaCargo.add(reservas);         
            }           
        } catch (SQLException ex) {
            System.out.println("ERRO!");
        }
        
        
        return listaCargo;
    }
    
     
    
    public List<Reservas> getFiltrarReservas(String colunaOrderBy, String colunaFiltro, String valor){   
        //Preenche um resultset com os dados do banco
        ConexaoMySql.selecionar("SELECT * FROM reserva WHERE "+colunaFiltro+" LIKE '%"+valor+"%' ORDER BY "+colunaOrderBy);
        
        List<Reservas> listaCargos = new ArrayList<>();
        
        try {
            while(ConexaoMySql.resultset.next()){  
                Reservas reservas = new Reservas();
                reservas.setCodigo(ConexaoMySql.resultset.getInt("reservas_id")); 
                reservas.setNumero(ConexaoMySql.resultset.getString("reservas_numero"));
                reservas.setStatus(ConexaoMySql.resultset.getString("reservas_status"));
                reservas.setData(ConexaoMySql.resultset.getString("reservas_datadereserva"));
                reservas.setCusto(ConexaoMySql.resultset.getDouble("reservas_custo"));
                
                listaCargos.add(reservas);         
            }           
        } catch (SQLException ex) {
            System.out.println("ERRO!");
        }
        
        return listaCargos;
    }
    
    
        
 
}
